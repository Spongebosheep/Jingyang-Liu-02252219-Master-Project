# Public technical-evidence repack

This archive is derived from `PSE_v10.2_R6_FINAL_WINDOWS_SAFE_2026-08-11.zip`.

The formal run records, validator outputs, saved model-call records, A/B materials,
MP/UCR materials and integrity records are retained. The following material was
removed from this public repack:

- `PSE/04_Core/10_requirements_and_benchmark/`, because it contains older
  identity-bearing consultation notes and pre-thesis requirement material.
- `PSE/04_Core/00_prov/source_HEAD_35c930d92119d47560879496902e928daf20ac02.zip`,
  because the same authoritative source tree is already present at the repository
  root and is documented under `docs/source_freeze/`.

The original controlled archive is retained offline. This public repack is not a
byte-identical replacement for that controlled archive. Thesis claims should be
read against the claim/evidence map in the repository root.
