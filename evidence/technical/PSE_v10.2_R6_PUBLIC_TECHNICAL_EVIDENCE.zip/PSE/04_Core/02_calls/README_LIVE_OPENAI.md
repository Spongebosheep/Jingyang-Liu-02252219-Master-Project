# Saved live OpenAI evidence

The frozen Formal 32 archive contains **183 actual OpenAI Responses API
calls**: 87 MVP calls embedded in runner records and 96 Baseline calls saved as
separate request/response JSON files. All recorded API statuses are completed
and all recorded API error fields are null. The call index records storage
locations and hashes without duplicating the large raw payloads.

No additional live check was run during this derived-stage build. This avoids
changing the frozen experiment and avoids implying that credentials or network
availability were revalidated on 2026-08-09. The original 183 calls are the
direct evidence for the executed comparison.
