# Post-formal offline QA note

The source snapshot is a GitHub-style ZIP and therefore contains no `.git`
directory. The first offline QA attempt verified the 155-file source manifest
but then produced Git-identity preflight failures (2 failed tests and 33 errors);
these do not show source-byte drift. That complete log is retained as
`offline_qa_20260809.txt`.

For an environment-compatible rerun, the exact verified source bytes were
copied to a temporary directory and wrapped in a new local Git repository. The
temporary wrapper commit (`f7df393…`) is **not** the original project commit and
is not represented as one; no tracked source byte was changed. The second log,
`offline_qa_git_wrapped_20260809.txt`, records:

- source manifest: 155/155 files OK;
- frozen specification validation: PASS;
- Django system check: zero issues;
- migration drift check: no changes detected;
- database migration: successful/no pending changes;
- test suite: 197/197 OK in 37.927 seconds.

This is supplementary post-formal environment verification. It is not a
retrospective claim that an identical log existed before Formal 32, and Formal
32 was not rerun.
