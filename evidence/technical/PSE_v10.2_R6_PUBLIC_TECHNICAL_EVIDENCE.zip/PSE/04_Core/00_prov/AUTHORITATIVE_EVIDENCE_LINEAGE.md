# Authoritative evidence lineage

1. `HISTORICAL v9 first 32`: clean archive SHA-256 `e018ca87176be4fea855d4f7c32fd7d596ce19972069117d2540047c337ea39f`. Historical iteration evidence only.
2. `CURRENT v10.2 second 32`: `Pu(1).zip` SHA-256 `ad44c600e96449ef385876c51a0d44c2e85ef0df989052f91e176505657e054c`; authoritative inner formal ZIP SHA-256 `c5904e3b39afdb1918aec2d1d4f300698b37794488c13066cfac31cc3af9d43e`.
3. `Q2-corrected coder inputs`: Coder01 kit `ac5f32bf...`, Coder02 kit `8b84a48f...`; these supersede the generic pre-coder workbooks without changing the blind evidence materials.
4. `Locked returns`: Coder01 `d3ad051f...bee7ca48`; Coder02 `efb1b3b...50d7ecec`.
5. `This post-coder layer`: machine results remain sourced to the immutable v10.2 archive; human results are derived from the two locked returns. v9 is not pooled.
