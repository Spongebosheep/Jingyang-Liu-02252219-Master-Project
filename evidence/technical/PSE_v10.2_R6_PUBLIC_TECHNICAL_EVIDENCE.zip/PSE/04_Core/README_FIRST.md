
# PurrStone v10.2 Evidence

Status: current shareable evidence archive, updated 2026-08-10 after UCR Phase 2 resolution and the separately bounded Baseline S7/S8 deterministic diagnostic. Private keys and identity-bearing original coder/resolution workbooks are excluded; exact SHA-256 hashes and clean reporting derivatives are retained.

## Headline results

- Formal 32: all 32 registered identities were attempted once with no retry or replacement.
- Completion: MVP 16/16; prompt-only Baseline 10/16; six Baseline failures retained.
- Human A/B scope: ten successfully completed matched pairs, two independent coders, no consensus round.
- A/B agreement: 84/88 exact ratings; all 88 applicable ratings within one point; overall preference agreement 8/10.
- Pair dispositions: six unanimous MVP, two unanimous Tie, two Baseline-versus-Tie disagreements; no unanimous Baseline preference.
- Supplementary MP: 8/9 nominal items and 4/5 unique text-source bundles preserved; SF-008 not preserved.
- Supplementary UCR: 3/46 unsupported proposition instances (6.5%); unique-text sensitivity 3/27 (11.1%). Initial independent agreement was 45/46 (97.8%), Cohen's κ = 0.789. The sole disagreement, SF-008-P02, was resolved as unsupported.
- Frozen MVP RAC remains 12/26 (46.1538%, FAIL).

The defensible conclusion is narrow: in this single scripted protocol, the MVP completed more registered runs and its completed-pair records received clearer participant-control and researcher-reviewability ratings. The evidence does not establish generally better interviews, useful insights, target-researcher adoption, scalability, production readiness or commercial superiority.

## Start here

1. `06_metrics/Results.xlsx` — descriptive results, denominators, requirements, claims and deviations.
2. `05_quality_review/04_ucr_phase2/UCR_Audit.xlsx` — both independent UCR labels, initial reliability and final resolution.
3. `09_reporting_content/RESULTS_POST_CODER.md` — report-ready bounded results.
4. `10_requirements_and_benchmark/TEACHER_REQUIREMENT_COVERAGE.md` — tutoring requirement coverage and remaining gaps.
5. `12_integrity/MANIFEST_VERIFICATION.json` — current whole-package hash verification; `PACKAGE_VERIFICATION.json` retains the core Formal 32/reporting structural checks.
6. `13_supplementary_diagnostics/baseline_s7_s8_review_layer/README_SCOPE.md` — post-formal deterministic S7/S8 downstream review-layer diagnostic and strict claim boundary.

## Layering rule

The raw run evidence in `00_version_and_provenance` through `04_scenarios` and the `06_metrics/FROZEN_*` files remain historical frozen records. Their `PENDING_MANUAL` UCR text records the machine-stage state at execution time and is not rewritten. The resolved UCR in `05_quality_review/04_ucr_phase2`, `06_metrics/Results.xlsx` and the current result JSON files is the later reporting layer.

The runs in `13_supplementary_diagnostics` are deterministic dry-run diagnostics, not Formal 32 attempts. They do not change the frozen Baseline completion count of 10/16, add complete pairs, or alter any A/B, MP or UCR result.

## Disclosed remaining gaps

- The advisory A/B consensus round was not performed.
- Only ten of the recommended sixteen complete pairs entered A/B review.
- The UCR proposition inventory was administrator-frozen from a pre-existing blind proposal without a separate coder-confirmation round; it is not coder-consensus segmentation.
- UCR is within-MVP only; no Baseline UCR or condition-level fidelity comparison exists.
- Target-researcher utility, usability and desirability were not evaluated.
- The evidence ZIP supports the report and viva; it does not replace either assessed deliverable.
