
# Evidence index

- `00_version_and_provenance`: source identity, frozen plan/contracts, lineage and original-input hashes.
- `01_clean_tests`: exact-byte offline QA, including the disclosed temporary Git wrapper.
- `02_live_openai`: index and manifest for 183 saved actual Responses API records.
- `03_scenarios/mvp`: all 16 current MVP run directories and archived Evidence Records.
- `04_scenarios/baseline`: all 16 current Baseline run directories, including six retained failures.
- `05_quality_review`: blinded A/B and MP materials, independent audits, raw disagreements and resolved UCR Phase 2 evidence.
- `06_metrics`: immutable frozen automatic outputs plus current descriptive result JSON/CSV/XLSX files.
- `07_implementation_status`: 28-row implementation status and claim-to-evidence map.
- `08_thesis_figures`: report figures, selected Evidence Record renders and the 32-run preview set.
- `09_reporting_content`: methods, results, limitations, insertion checklist, explainer and viva support.
- `10_requirements_and_benchmark`: teacher/assessor traceability, terms, derivation chain, SOTA context, risks and timeline.
- `11_iteration_comparison`: bounded v9 first-32 versus v10.2 current second-32 comparison; no pooling.
- `12_integrity`: deviations, full manifest, leakage scan and package verification.
- `13_supplementary_diagnostics`: post-formal deterministic Baseline S7/S8 downstream review-layer records, source-link audit and rendered Evidence Records; excluded from Formal 32 counts and comparative results.

Identity-bearing original return/resolution workbooks are intentionally outside this shareable archive. `05_quality_review/04_ucr_phase2/Return_Hashes.csv` provides their exact hashes and the public/private treatment.
