# Manifest scope

`PACKAGE_MANIFEST_SHA256.csv` and `SHA256SUMS.txt` cover every package file except themselves and `MANIFEST_VERIFICATION.json`. `MANIFEST_VERIFICATION.json` records the immediate build-time recheck. The delivered ZIP SHA-256 covers the complete tree, including all integrity files.

The manifest includes `13_supplementary_diagnostics`, whose records are explicitly post-formal deterministic dry runs. Their inclusion in package integrity coverage does not include them in the Formal 32 denominator, completed-pair selection, automatic formal metrics, A/B review, MP or UCR.
