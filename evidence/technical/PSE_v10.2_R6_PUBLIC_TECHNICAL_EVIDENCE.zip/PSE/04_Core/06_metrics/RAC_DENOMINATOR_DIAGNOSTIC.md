# RAC denominator diagnostic — frozen result retained

The frozen calculator reports MVP Review Audit Completeness (RAC) as
`12/26 = 46.1538%`, because its denominator includes fourteen pending
overall-review placeholder rows from runs with no scripted review event. The
frozen result is preserved unchanged and must be reported as such.

A diagnostic interpretation would count only actually executed item-level and
overall review actions; that scope yields 12 recorded actions with complete
fields. This diagnostic **does not replace the frozen RAC result**, because the
metric contract's phrase “all completed ... review events” and the implemented
denominator differ. Resolve the definition prospectively before another study.
