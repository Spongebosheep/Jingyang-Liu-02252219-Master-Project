
# MP/UCR contract clarification

Two frozen texts define different eligible universes:

- `metrics.v3` selects final reviewer-approved or edited evidence items. This yields nine reviewed MVP items.
- `V10_2_METHOD_AMENDMENT.md` limits A/B, MP and UCR to complete matched pairs. The S7/S8 runs containing those nine items have incomplete Baseline counterparts and are outside the ten complete A/B pairs.

The frozen machine exporter therefore produced no primary MP/UCR rows and correctly retained `PENDING_MANUAL` at the machine stage. Those frozen files remain unchanged.

The later human analysis is reported as a **supplementary contract-clarification analysis** using the metric-level item rule:

- Fixed universe: nine final-reviewed MVP items (`is_included=true` and review status approved/edited), representing five unique text-source bundles.
- MP: 8/9 nominal and 4/5 unique bundles preserved.
- UCR: two independent Phase 2 returns over 46 proposition instances; initial agreement 45/46 (97.8%), κ = 0.789; final 3/46 unsupported (6.5%).
- Duplication sensitivity: 3/27 unique proposition texts unsupported (11.1%).

The common UCR inventory was administrator-frozen from a pre-existing blind proposal without a separate coder-confirmation round. MP/UCR must remain separate from the ten-pair A/B analysis and cannot support a Baseline comparison or universal fidelity claim.
