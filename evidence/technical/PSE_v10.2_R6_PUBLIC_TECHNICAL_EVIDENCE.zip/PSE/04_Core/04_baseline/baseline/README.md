# prompt_only_baseline formal scenario index

- Registered attempts: 16
- Completed runners: 10
- Validator PASS / formal-evidence eligible: 10
- Archived Evidence Record HTML files: 10

`RUN_INDEX.csv` points into the original frozen evidence ZIP preserved under
`00_version_and_provenance/`. Raw runner, validator, HTTP, request, response,
parsed-output and evidence-render artefacts remain in that immutable ZIP. This
derived package does not silently duplicate or modify them.
