# Baseline retained-failure analysis

Six of sixteen frozen Baseline attempts failed and were retained without retry
or replacement. These are measured condition outcomes. The saved OpenAI API
responses completed successfully; the failures arose from prompt-only output
rule adherence and, in three cases, a secondary runner response after the
scripted trajectory could no longer complete.

| Pair | Class | Evidence-based root cause | Boundary |
|---|---|---|---|
| S1-R02 | STRICT_ADAPTER_SEMANTIC_CONTRADICTION | API returned covered + move_next but retained non-empty missing_information. | Same frozen request hash passed in R01 and R03; this is nondeterministic rule adherence, not an API outage. |
| S2-R03 | STRICT_ADAPTER_SEMANTIC_CONTRADICTION | API returned covered + move_next but retained non-empty missing_information. | Strict local adapter rejected the internally inconsistent successful API response. |
| S3-R02 | WRONG_FINAL_ACTION_THEN_SECONDARY_404 | At the final scripted topic, the model returned partially_covered + ask_follow_up instead of covered + move_next. | The session therefore did not complete; the subsequent Evidence Record request returned 404. |
| S6-R02 | STRICT_ADAPTER_SEMANTIC_CONTRADICTION | API returned covered + move_next but retained non-empty missing_information. | Strict local adapter rejected the internally inconsistent successful API response. |
| S7-R01 | WRONG_FINAL_ACTION_THEN_MISSING_DIGEST | At the final scripted topic, the model asked an unregistered follow-up instead of moving next. | Digest generation never occurred; the runner's scripted review action then raised StructuredDigestItem.DoesNotExist. |
| S8-R01 | WRONG_FINAL_ACTION_THEN_MISSING_DIGEST | At the final scripted topic, the model asked an unregistered follow-up instead of moving next. | Digest generation never occurred; the runner's scripted review action then raised StructuredDigestItem.DoesNotExist. |

Do not relabel the 404/DoesNotExist symptoms as API failures. Do not infer a universal Baseline failure rate beyond this frozen harness and model configuration.
