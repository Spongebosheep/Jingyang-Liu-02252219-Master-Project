# Reflection and ownership prompts — student completion required

Do not submit generated first-person claims without checking them against your
own experience. For each prompt, write in your own voice and cite a real dated
artefact, meeting, commit, test or decision.

1. **Initial assumption:** What did you originally assume about scaling
   interviews or summarisation? Which evidence challenged it?
2. **Requirement derivation:** Which requirement was genuinely stakeholder- or
   literature-derived, and which was primarily an engineering constraint? How
   did you learn to distinguish them?
3. **Architecture choice:** What alternatives did you personally consider for
   the web stack, orchestration and review model? What evidence existed at the
   time, and what rationale is only retrospective?
4. **Failure as evidence:** How did the six retained Baseline failures change
   your understanding of evaluation, retries and denominator integrity?
5. **Reproducibility:** What did the identical-request/non-identical-output case
   teach you about frozen identity versus deterministic output?
6. **Human judgement boundary:** Why can automatic source-link checks not
   replace MP, UCR or output-quality coding?
7. **Ethics and consent:** What did the consent audit teach you about completed
   forms, quotation permission and the difference between requirements input
   and usability validation?
8. **Tool defect:** What did the off-by-one workbook formula defect reveal about
   relying on cached Excel PASS cells? How did the external validator change
   the process?
9. **Method conflict:** How would you prospectively prevent the MP/UCR contract
   conflict and RAC denominator ambiguity?
10. **Scope discipline:** Which tempting claims did you remove because the
    evidence did not support them?
11. **Personal contribution:** Identify three concrete things you designed,
    implemented, tested or decided. Provide evidence and distinguish your work
    from AI/tool assistance.
12. **Next iteration:** If given four more weeks, what would you do first, why,
    and what acceptance criterion would decide success?

For every answer use: `Situation → your decision/action → evidence → result or
failure → what you learned → what you would change`.
