
# PurrStone in plain language

## What is it?

PurrStone is a research prototype for a bounded, text-based, semi-structured interview. A researcher locks a Protocol containing topics, required information, question boundaries and a one-follow-up limit. The prototype asks questions, records typed participant answers and saves a short inspectable decision after each turn. Topics can be covered, partially covered, skipped, stopped or not reached.

After the interview, PurrStone creates provisional structured evidence items linked to participant messages. A researcher checks the transcript and sources, then Includes/approves, Edits or Excludes each item. The system retains reviewer, time, reason and before/after text where required, and produces an HTML Evidence Record with evidence, limitations, review state and audit material.

## Who is it for?

The intended user is a qualitative or design researcher who needs repeated interviews to remain visibly tied to a guide and participant sources. This is a design target, not a validated adoption result; no target-researcher utility/usability study was completed.

## What did the evaluation show?

- All 16 MVP attempts completed and passed; ten of 16 prompt-only Baseline attempts completed.
- Two coders reviewed the ten successfully completed A/B pairs: 84/88 ratings matched exactly and 8/10 preferences matched.
- Coverage and grounding means were equal in the completed-pair subset. MVP scored higher for participant control and researcher reviewability; not for probing.
- Supplementary MP found 8/9 nominal items and 4/5 unique bundles preserved.
- Supplementary UCR found 3/46 unsupported proposition instances (6.5%); unique-text sensitivity was 3/27 (11.1%). Initial agreement was 45/46 and κ = 0.789.
- The archive contains 26 Evidence Record HTML files and 183 saved actual OpenAI response records.

## What has not been shown?

The evidence does not show generally better interviews or insights, universal meaning preservation, a Baseline UCR comparison, time saving, target-researcher usefulness, commercial superiority or production readiness. The UCR inventory was administrator-frozen without a separate coder-confirmation round. Target-user value requires a separate ethics-authorised study.
