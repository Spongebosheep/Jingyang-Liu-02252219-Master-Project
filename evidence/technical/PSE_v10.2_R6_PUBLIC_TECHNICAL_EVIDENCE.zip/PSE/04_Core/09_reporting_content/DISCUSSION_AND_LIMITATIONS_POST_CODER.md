
# Discussion and limitations: required boundaries

1. The evaluation used one scripted PurrStone/Sensory Overload protocol and fixed participant inputs; it is not a natural-participant or cross-domain study.
2. Six Baseline runs failed under the strict prompt-only adapter. Completion is a workflow outcome, but only ten complete pairs support text-quality ratings.
3. Human evidence contains two coders and ten A/B pairs. Results are descriptive; no inferential significance test is reported.
4. A/B consensus was omitted. Four score and two preference differences remain initial disagreements.
5. MP is supplementary, covers final-reviewed MVP evidence only, and contains nine nominal items but five unique text-source bundles.
6. UCR is supplementary within-MVP: 3/46 unsupported proposition instances, with 3/27 unique-text sensitivity. The inventory was administrator-frozen without separate coder confirmation and no Baseline UCR exists.
7. Initial UCR agreement was 45/46 (97.8%), κ = 0.789. The single resolution must not be described as post-resolution 100% independent agreement.
8. Source-link validation establishes linkage, not semantic fidelity. SF-008 demonstrates why these checks remain separate.
9. Frozen RAC is 12/26 and FAIL; an executed-event diagnostic cannot replace the frozen contract result.
10. The package does not evaluate target-researcher usefulness, usability, desirability, time saving, review burden, scalability, security or production operations.
11. Public vendor documentation positions the prototype but is not a hands-on commercial comparison.
12. The ZIP supports auditability but does not replace the assessed report or viva. Essential results and limitations belong in the report body.
