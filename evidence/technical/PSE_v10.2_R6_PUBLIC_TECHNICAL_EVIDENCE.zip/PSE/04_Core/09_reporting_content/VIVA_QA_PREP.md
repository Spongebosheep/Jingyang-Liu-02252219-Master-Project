
# Viva preparation: evidence-bound answer points

These are fact anchors, not a script. Verify them and answer in your own words.

## What is the contribution?

An evaluated prototype for bounded, auditable AI-moderated semi-structured interviewing. Its evaluated chain runs from a locked Protocol and per-turn decision state to source-linked draft evidence, explicit limitations and attributable researcher review. It is not a commercially superior or production-ready system claim.

## Who uses it?

The intended user is a qualitative/design researcher who wants repeated interviews tied visibly to a guide and participant sources. One clearly consented consultation and literature informed requirements; target-user value was not validated.

## Why LangGraph and Django?

Django keeps session, protocol, review/audit models, auth, commands and Evidence Record rendering in one tested stack. LangGraph supports explicit stateful routing. Neither was proven optimal by a controlled architecture study; the prompt-only Baseline compares orchestration configurations, not LangGraph alone.

## Why `gpt-4.1-mini`?

The same frozen model label was used for both conditions and the saved formal run. This supports within-study fairness, not a claim that it is the best model.

## What is the strongest result?

MVP completed 16/16 versus 10/16 Baseline under the frozen scripted harness. Among ten successfully completed pairs, coverage and grounding means were equal, probing did not favour MVP, and participant-control/reviewability means were higher for MVP. These are descriptive results.

## What did the A/B coders agree on?

They matched on 84/88 applicable ratings and were within one point on all 88. Preference matched on 8/10 pairs: six unanimous MVP, two unanimous Tie and two Baseline-versus-Tie disagreements. No A/B consensus round was performed.

## Why were only ten pairs coded?

Only pairs with both runs completed, validated and eligible can be scored. Six Baseline runs failed. The minimum eight was met; the recommended sixteen was missed. Nothing was retried or backfilled.

## Were failures API outages?

No. The archive retains 183 actual response records. Three `parse_error` states are local semantic/parse outcomes, not transport outages. Failure analysis separates contradictory coverage/action outputs from extra-follow-up trajectories and secondary runner symptoms.

## What are the MP and UCR results?

They are supplementary within-MVP because the frozen item rule and complete-pair amendment conflict and S7/S8 Baseline counterparts did not complete. MP is 8/9 nominal and 4/5 unique bundles preserved. UCR is 3/46 unsupported (6.5%), with 3/27 unique-text sensitivity (11.1%).

## How reliable was UCR coding?

Initial independent agreement was 45/46 (97.8%), κ = 0.789. Coder01 marked three unsupported; Coder02 marked two. SF-008-P02 was the only disagreement and was resolved as unsupported. Resolution does not turn the initial reliability into 100% agreement.

## What is the UCR method limitation?

The administrator froze a pre-existing blind 46-row proposal before Phase 2 labels, but a separate coder-confirmation round for that common inventory was omitted. The result is not coder-consensus segmentation and there is no Baseline UCR.

## What is wrong with RAC?

The frozen calculator reports 12/26 because fourteen pending overall-review placeholders enter its denominator. Preserve that FAIL result; the executed-event view is diagnostic only.

## Did you validate usefulness or usability?

No. Scripted scenarios, tests and requirements consultation do not show target-researcher usefulness, usability or desirability. A new ethics-authorised realistic-task study is required.

## What should happen next?

Complete an A/B consensus round if the advisory workflow must be closed; prospectively agree the MP/UCR unit and inventory-confirmation process; run an ethics-authorised target-researcher task study; then add load, security and resilience evaluation before any production claim.
