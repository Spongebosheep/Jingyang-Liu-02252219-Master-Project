
# Results: v10.2 evidence

## Completion and automatic checks

- MVP: 16/16 completed, validator PASS and formally eligible.
- Prompt-only Baseline: 10/16 completed and eligible; six failures retained without retry.
- Ten complete matched pairs entered A/B review; the minimum of eight was met and the recommended sixteen was not.
- The archive retains 183 actual OpenAI response records: 87 MVP and 96 Baseline. The manifest marks 180 `completed` and three `parse_error`; these are local semantic/parse validation outcomes, not API transport outages.
- Frozen MVP automatic metrics were AI 102/102, AC 86/86, SLC 9/9, MIV 8/8, PCC 2/2 and TCR 80/80.
- Frozen MVP RAC remains 12/26 (46.1538%, FAIL) because the implemented denominator includes fourteen pending overall-review placeholders.

## Independent A/B review

Across 88 applicable score cells, coders agreed exactly on 84/88 (95.5%); every score was within one point. Preferences agreed in 8/10 pairs. Coder01 preferred MVP in six, Baseline in two and tied two. Coder02 preferred MVP in six and tied four. Pair dispositions were six unanimous MVP, two unanimous Tie and two Baseline-versus-Tie disagreements. No pair was unanimously Baseline.

Mean coder-pair ratings were Q1 4.4/4.4, Q2 4.5/5.0, Q3 4.9/4.9, Q4 5.0/4.1 and Q5 5.0/4.5 (MVP/Baseline). Q2 contains only four eligible pairs; its difference came from Coder01, while Coder02 rated both conditions 5.0.

## Meaning preservation and unsupported content

Both coders gave identical MP labels on all nine supplementary items. Eight of nine nominal items (88.9%) were preserved; four of five unique text-source bundles (80.0%) were preserved. Both marked SF-008 not preserved because the edited text added a sensory-overload category and causal attribution while omitting that the carriage stopped between stations.

For UCR, initial Phase 2 agreement was 45/46 (97.8%), κ = 0.789. Coder01 marked 3/46 unsupported and Coder02 marked 2/46. The sole disagreement, SF-008-P02, was resolved as unsupported. Final UCR is **3/46 (6.5%)**; unsupported IDs are SF-008-P02, SF-008-P03 and SF-008-P06. Because repeated proposition text appears across items, the unique-text sensitivity result is **3/27 (11.1%)**.

UCR is supplementary within-MVP. The inventory was administrator-frozen without a separate coder-confirmation round and contains no Baseline evidence. The result does not establish a condition-level fidelity difference. Initial 97.8% agreement and κ must be reported; resolution is not 100% independent agreement.

## Bounded conclusion

MVP did not outperform Baseline on every rated dimension: coverage and grounding/fidelity means were equal among completed pairs, and Baseline probes were rated at least as highly. The narrower supported finding is that, under this frozen scripted workflow, MVP completed more registered runs and produced clearer participant-control and researcher-review records. The evidence does not establish generally better interviews, better insights, usefulness, scalability, production readiness or commercial-platform superiority.
