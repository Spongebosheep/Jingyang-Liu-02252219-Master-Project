
# Proposed report structure and 35-page body budget

The formal assessment brief requires 12-point text, a main body no longer than 35 pages, essential evidence in the body and a final PDF. Appendices are not guaranteed to be read. The assessed viva is 45 minutes.

| Section | Pages | Essential content in the body |
|---|---:|---|
| 1. Abstract and contribution | 1 | Problem, intended user, bounded contribution, main result and primary limitation. |
| 2. Context, stakeholder need and research question | 3 | Master Project framing, one consented consultation with limits, RQ and claim boundary. |
| 3. SOTA and conceptual framing | 5 | Semi-structured interview methods, faithfulness/audit literature, dated commercial capability context. |
| 4. Requirements and success criteria | 3 | Five requirements, evidence origins, engineering constraints and observable criteria. |
| 5. Design development and architecture | 5 | Alternatives/rationale, evidence flow, key iterations, UI/review mechanism. |
| 6. Implementation | 4 | Django/LangGraph/data model, source links, controls, review/audit and tested scope. |
| 7. Evaluation method | 4 | Formal 32, comparator, scenarios, metrics, pair selection, two-coder A/B/MP/UCR and deviations. |
| 8. Results | 4 | Completion, automatic denominators, six failures, A/B, supplementary MP and resolved UCR. |
| 9. Discussion and limitations | 3 | Interpretation, contract/RAC issues, user-value/scale/security limits and future study. |
| 10. Reflection and project management | 2 | Authentic ownership, learning, timeline, risk and ethics/consent handling. |
| 11. Conclusion | 1 | Evidence-bounded contribution and next decisive experiment. |
| **Total** | **35** | Keep raw manifests, full 28-row map, call index and detailed coder tables outside the body. |

For the viva, allocate enough time to explain the contribution, requirements, design logic, Formal 32, human review, UCR boundary, limitations and personal ownership. The ZIP is supporting evidence; it is not a substitute for an authentic first-person reflection or viva answer.
