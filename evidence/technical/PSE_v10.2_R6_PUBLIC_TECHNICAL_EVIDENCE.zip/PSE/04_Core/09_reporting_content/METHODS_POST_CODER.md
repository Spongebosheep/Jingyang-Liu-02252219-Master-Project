
# Methods: v10.2 evaluation and human review

## Machine evaluation

The current dataset registered 16 scenario-repetition identities under each of two conditions: the LangGraph-managed MVP and a prompt-only Baseline. All 32 were attempted exactly once with no replacement. The same frozen participant inputs, scenario identifiers, model label and protocol were used within each pair. The Baseline did not call LangGraph routing. Every failure was retained.

MVP completed and passed validation in 16/16 attempts. Baseline completed in 10/16; six execution failures were retained. Completion uses the full 16-attempt denominator per condition. Human quality scores use only the ten pairs where both conditions completed, because scoring a missing artefact as text quality would mix completion with output quality.

## Human A/B review

Two coders independently reviewed ten condition-masked pairs. Q1 assessed protocol coverage; Q2 assessed missing-information probe relevance and neutrality only in four genuine-probe pairs; Q3 assessed grounding and fidelity; Q4 assessed participant clarity and control; Q5 assessed researcher reviewability. Six non-probe pairs had Q2 prefilled N/A. Each coder also recorded A/B/Tie preference, confidence, rationale and flags.

Original return workbooks were preserved and hash-locked. Excel serialized visible ISO timestamps as numeric date values. Strict validation therefore reports timestamp-type errors; a deterministic compatibility audit accepts them only when the exact +08:00 display format and declared interval match. No source workbook was edited.

The condition map was applied after both returns were received and hash-locked. The package cannot independently establish whether an administrator had never inspected the key earlier. No blind A/B consensus round was performed; initial disagreements remain visible.

## Supplementary MP and UCR

The frozen metric-level contract and complete-pair amendment define different MP/UCR item universes. A supplementary analysis therefore examined nine final-reviewed S7/S8 MVP items, representing five unique text-source bundles. No corresponding Baseline item entered because the S7/S8 Baseline runs did not complete.

Both coders independently judged meaning preservation. For UCR, Phase 1 segmentations contained 52 proposals per coder. An administrator then froze a pre-existing blind common proposal of 46 proposition instances (27 unique texts) before Phase 2 labels. Separate coder confirmation of the inventory was omitted; the denominator is not coder-consensus segmentation.

The two Phase 2 returns were compared by proposition ID. Initial agreement was 45/46 (97.8%), with Cohen's κ = 0.789. The one disagreement, SF-008-P02, was separately resolved as unsupported while both initial judgements were retained. UCR is the final number of unsupported proposition instances divided by 46. A 27-unique-text calculation is reported as duplication sensitivity. The original identity-bearing workbooks remain in a private hash-locked archive; the shareable package contains clean derivatives and exact hashes.

## Historical comparison

The v9 first-32 archive documents iteration only. It differs in code commit, protocol and metric hashes, environment and Baseline policy. Its runs and old human ratings are not pooled with the current dataset.
