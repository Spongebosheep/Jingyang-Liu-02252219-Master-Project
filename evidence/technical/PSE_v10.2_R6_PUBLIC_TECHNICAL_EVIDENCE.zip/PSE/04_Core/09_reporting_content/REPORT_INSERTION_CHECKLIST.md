
# Report insertion checklist

- Methods: state 32 attempts, no retries, full completion denominators and ten complete-pair A/B denominator.
- Methods: define Q1-Q5 and the corrected Q2 N/A rule.
- Methods: disclose two independent coders, raw A/B agreement, no A/B consensus and timestamp compatibility handling.
- Methods: describe UCR inventory freeze, 46-instance/27-unique units, independent coding and separate resolution.
- Results: include 16/16 versus 10/16 completion and six retained failure classes.
- Results: include A/B means with per-metric denominators; do not sum Q1-Q5 into an unvalidated total.
- Results: include 84/88 exact rating agreement and 8/10 preference agreement.
- Results: include six unanimous MVP, two unanimous Tie and two Baseline-versus-Tie dispositions.
- Results: report MP as supplementary: 8/9 nominal and 4/5 unique preserved; identify SF-008.
- Results: report UCR as supplementary within-MVP: 3/46 (6.5%); unique-text sensitivity 3/27 (11.1%).
- Reliability: report initial UCR agreement 45/46 (97.8%) and κ = 0.789; never call resolution 100% independent agreement.
- Limitations: retain RAC 12/26, ten-pair shortfall, no A/B consensus, administrator-frozen UCR inventory, no Baseline UCR, scripted scope and no target-user study.
- Iteration: use v9 only as historical evidence; do not pool 64 attempts or reuse old human results.
- Main body: include essential tables/figures; do not rely on an appendix or ZIP being read.
