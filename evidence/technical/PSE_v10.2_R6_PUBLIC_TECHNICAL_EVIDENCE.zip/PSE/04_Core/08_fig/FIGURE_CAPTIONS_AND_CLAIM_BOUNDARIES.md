
# Figure captions and claim boundaries

## Figure 1 — Formal 32 completion and codable pairing

All registered identities were attempted exactly once. MVP completed 16/16; the prompt-only Baseline completed 10/16. Ten of sixteen planned matched pairs were therefore eligible for blinded A/B review. The minimum of eight was met; the recommended target of sixteen was not. Completion is not interview quality.

## Figure 2 — Selected automatic metrics

Frozen descriptive numerators/denominators for action inspectability, action consistency, missing-information visibility, participant-control compliance and topic-coverage representation. Source-link coverage is omitted because the Baseline denominator is zero. RAC is omitted because the frozen 12/26 result uses a placeholder-row denominator and requires separate disclosure. These are scripted-corpus ratios, not population estimates.

## Figure 3 — Baseline failure mechanisms

Evidence-based grouping of six retained Baseline failures. Three successful API responses contained contradictory coverage/action structure and were rejected by the local adapter. Three requested another follow-up at the end of the frozen trajectory; later 404 or missing-digest errors were secondary runner symptoms. No failure was retried or replaced.

## Figure 4 — Auditable evidence flow

The prototype connects a locked Protocol and participant input to inspectable decision records, structured draft evidence, validated source links, attributable researcher actions and an Evidence Record. Provenance checks do not establish semantic fidelity. Supplementary MP found 8/9 nominal items preserved; supplementary UCR found 3/46 unsupported proposition instances, with 3/27 in the unique-text sensitivity analysis.

## Figure 5 — Post-coder A/B metric means

Descriptive means from two independent coders across the ten successfully completed matched pairs. Q1, Q3, Q4 and Q5 contain 20 coder-pair ratings per condition; Q2 contains eight ratings per condition from four genuine-probe pairs. Control and reviewability favour MVP in this subset, coverage and grounding are equal, and probing does not favour MVP. Six failed Baseline runs remain in the separate completion analysis.

## Figure 6 — Pair outcomes without consensus

Raw preferences produce six unanimous MVP outcomes, two unanimous Ties and two unresolved Baseline-versus-Tie differences. No pair is unanimously Baseline. No consensus round was performed.

## Evidence Record render set

The selected PDFs/PNGs and complete 32-image audit set are post-run renders from saved frozen HTML. Filenames retain exact run IDs. Six failed Baseline attempts have labelled derived failure cards because no Evidence Record exists; those cards are not UI screenshots. Saved HTML, JSON/CSV state and validator results remain authoritative.
