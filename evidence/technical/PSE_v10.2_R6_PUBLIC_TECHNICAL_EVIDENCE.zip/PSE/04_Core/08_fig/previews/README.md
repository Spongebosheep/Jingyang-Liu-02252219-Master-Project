# Current v10.2 run previews

There is one preview per registered formal attempt. The 26 completed-run images are first-page renders of the actual frozen Evidence Record HTML. The six failed Baseline attempts have clearly labelled derived status cards because no Evidence Record exists. Those cards are not UI screenshots. The manifest links every preview to its run_id and source; screenshots/previews never replace raw state exports or validator results.
