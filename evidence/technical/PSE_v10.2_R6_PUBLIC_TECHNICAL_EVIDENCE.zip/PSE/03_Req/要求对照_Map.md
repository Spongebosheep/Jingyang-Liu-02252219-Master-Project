# 评分与老师要求对照 / Assessment and teacher map

依据学生提供的 Module descriptor and assessment brief，六项标准都必须达到 passing level。证据包只提供可审计支持，不能替代报告和口试。

| 标准 / Criterion | 主要证据 / Evidence | 状态与边界 / Status and boundary |
|---|---|---|
| Contextual Investigation | `04_原证据_Core/10_requirements_and_benchmark` | 已有SOTA、竞品和需求链；目标研究者需要仍须由stakeholder research支撑。 |
| Project Management | `04_原证据_Core/00_version_and_provenance`；`99_校验_Integrity` | 版本、失败保留、风险和hash可审计；报告需解释计划调整与伦理边界。 |
| Design Engineering Process | `04_原证据_Core/03_scenarios`；`11_iteration_comparison` | MVP 16/16到达各注册场景的定义终点；S7/S8正式运行覆盖revision_requested，成功审批与审批后重开仅有离线测试。 |
| Validation | `01_结果_Results/总表_Results.xlsx`；Formal 32；A/B；MP/UCR；SLC/RAC | 比较与指标已增强；仍不能证明真实研究者效用、采用或跨协议规模化。 |
| Reflection | `04_原证据_Core/09_reporting_content/REFLECTION_AND_OWNERSHIP_PROMPTS.md` | 只有证据锚点；必须由学生写真实第一人称学习与改进。 |
| Communication | 本README、结果表、report text和viva prep | 需在35页正文和45分钟口试中清晰叙述；ZIP不是独立评分提交。 |

老师反馈对应：竞品benchmark见`10_requirements_and_benchmark`；设计决定与迭代见`DESIGN_ALTERNATIVES_AND_RATIONALE.md`及`11_iteration_comparison`；Formal 32证明各脚本场景达到定义终点，但不代表全部正向路径均已正式验证；替代方案比较和清晰指标见本版总表；learning journey须由学生本人完成。
