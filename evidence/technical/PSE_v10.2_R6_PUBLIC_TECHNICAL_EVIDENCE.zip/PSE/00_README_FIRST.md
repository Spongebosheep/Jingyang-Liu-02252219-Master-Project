# PurrStone v10.2 R6 — Windows-safe final evidence package

## Start here

1. `01_Results/总表_Results.xlsx` — all main numerical results.
2. `01_Results/论文结果_Report_Text.md` — concise Chinese/English result text.
3. `02_Coding/00_Raw/README.md` — 11 raw coder/coordination workbooks grouped by workflow.
4. `02_Coding/范围说明_Scope.md` — why the earlier MVP and later Baseline analyses must not be pooled.
5. `03_Req/要求对照_Map.md` — assessment-criteria and assessor-feedback navigation.
6. `04_Core` — Formal 32 runs, A/B, MVP MP/UCR, benchmark and raw run evidence.
7. `99_Check` — current package manifest, path map and verification record.

## Windows extraction fix

- The longest internal path in the previous ZIP was 200 characters. This package caps every internal path at 97 characters.
- Timestamped run folders are shortened only as packaging aliases: for example, an MVP S1/R1 folder becomes `ms1r1`; a Baseline S7/R1 folder becomes `bs7r1`; the validator subfolder becomes `v`.
- `99_Check/PATH_MAP.csv` maps every preserved source path to its shortened path and retains SHA-256 and size.
- Evidentiary payload bytes are unchanged. Only this package-level README and the outer `99_Check` records were regenerated.
- Historical manifests inside `04_Core/12_integrity` describe the canonical pre-repack tree. Use `99_Check/PATH_MAP.csv` to translate their paths; their referenced file bytes remain unchanged.

## Raw-workbook boundary

- The package contains 11 raw coder/coordination `.xlsx` files under `02_Coding/00_Raw`.
- Eight are independent coder returns and three are administrator reconciliation, audit or resolution records.
- The first MVP-only Phase 1 administrator proposal/reconciliation Excel remains unavailable. The 46-proposition inventory must not be described as coder-consensus segmentation.

## Current results

- Formal completion: MVP 16/16; Baseline 10/16; 10 complete pairs.
- A/B: Q1 4.4 vs 4.4; Q2 4.5 vs 5.0 (4 applicable pairs); Q3 4.9 vs 4.9; Q4 5.0 vs 4.1; Q5 5.0 vs 4.5; overall preference agreement 8/10; raw blind A/B/Tie kappa 0.688.
- Earlier MVP-only final-reviewed: MP 8/9; UCR 3/46; UCR kappa 0.789.
- Later Baseline pre-review supplement: MP 45/45; UCR 0/220; deduplicated 9/9 and 0/46; kappa not estimable.
- SLC: Formal MVP 9/9; Formal Baseline 0/0 INCOMPLETE; later Baseline diagnostic 9/9 and all candidates 10/10.
- RAC: Formal MVP 12/26 and executed actions 12/12; Formal Baseline frozen 0/10 INCOMPLETE; later Baseline diagnostic 12/12 with both runs PASS.

## Claim boundary

This package supports bounded-workflow feasibility under one frozen protocol and scripted inputs, plus descriptive comparison. It does not prove generally better interviews, target-researcher utility or adoption, cross-protocol scalability, production readiness, or superiority to commercial platforms.
