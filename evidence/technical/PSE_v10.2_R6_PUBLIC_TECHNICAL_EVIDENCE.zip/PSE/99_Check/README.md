# Windows-safe package integrity

- Source package SHA-256: `3b3fe2eae9a89252183c7d0ff6eb58d191399bf8bbf9b80827835ba32f35405c`
- Preserved source payload files: 967
- Packaging paths shortened: 967
- Raw coder/coordination workbooks in `02_Coding/00_Raw`: 11
- Replaced package-level files: `PSE/00_先读_README.md` and 3 former outer-integrity files.
- Payload rule: every file listed in `PATH_MAP.csv` is copied byte-for-byte from the source ZIP.
- `MANIFEST_SHA256.csv` verifies the actual Windows-safe package paths. It excludes itself and `VERIFY.json` to avoid circular hashes.
