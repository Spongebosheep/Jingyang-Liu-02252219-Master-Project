# Thesis-Figure Completion Report — `Stage 8` Working Label

Date: 2026-08-08 (Asia/Taipei)  
Mode: read-only derivation from frozen evidence; no runner, validator, model call, API request, scenario, oracle, or frozen source file was modified or re-executed.

Numbering note: the preserved checkpoint defines post-experiment workstreams A–E and does not formally define a numbered Stage 8. `Stage 8` is therefore a conversation-level working label here; methodologically, this report completes workstream C, screenshots and thesis-figure sourcing.

## Completion result

- counted formal attempts covered: 32/32;
- output-review screenshots: 17;
- validator-failure screenshots: 18;
- total PNG screenshots: 35;
- pre-existing S1 PNGs preserved: 6;
- newly rendered PNGs: 29;
- every screenshot source hash verified against the frozen 603-file inventory: yes;
- screenshot-level provenance manifest: `screenshot_manifest.csv`.

Three completed but formally ineligible MVP attempts (S2-R01, S7-R01, and S8-R01) have both an output-review screenshot and a validator-failure screenshot. Fifteen stopped prompt-only baseline attempts have failure screenshots only because they did not reach a final output-review page. This is why 32 attempts produce 35 screenshots.

## Scenario coverage

| Scenario | Attempts covered | Output review PNG | Failure PNG | Total PNG |
|---|---:|---:|---:|---:|
| S1 | 6 | 4 | 2 | 6 |
| S2 | 6 | 3 | 4 | 7 |
| S3 | 6 | 3 | 3 | 6 |
| S4 | 2 | 1 | 1 | 2 |
| S5 | 2 | 1 | 1 | 2 |
| S6 | 6 | 3 | 3 | 6 |
| S7 | 2 | 1 | 2 | 3 |
| S8 | 2 | 1 | 2 | 3 |

## Rendering and provenance

New screenshots were rendered from archived HTML or from a derived, portable HTML summary of the archived validator JSON. New output-review captures use a 1440×4000 viewport; failure summaries use 1440×1100. The six pre-existing S1 PNGs and two pre-existing S1 failure-summary HTML files were preserved byte-for-byte. Their original exact render timestamps and engines were not independently recorded, so the manifest identifies their file modification time and labels that limitation explicitly.

The figure set supports interface-presentation and archived-state claims only. It does not establish outcome quality, meaning preservation, unsupported-content control, researcher acceptance, scalability, natural-use reliability, or comparative superiority. Machine-readable JSON and validator records remain the primary evidence for state relationships.
