# PurrStone v9 Formal Deviation and Retained-Finding Log — FINAL

Date: 2026-08-08 (Asia/Taipei)

This file separates operational deviations from experimental findings. A failed or stopped formal run is not automatically an operational deviation.

## A. Operational deviation

### D-01 — Extra S1-R01 MVP runner record

- Pair: `S1-R01`
- Condition: MVP
- Excluded run ID: `mvp-s1-r01-20260807T141534179315Z-346b7b4e`
- Execution status: completed
- Validator count: 0
- Runner SHA-256: `85A5C44911EAE1277F687C796672B5DF901BBB004F11FCEB2AD361B67FE59777`
- Treatment: retained physically; excluded from the 32 planned attempts and every formal denominator.
- Rationale: the frozen selection rule requires exactly one validated MVP and one validated prompt-only baseline for each of the 16 pairs.
- Cause: not inferred from the archived record. The evidence establishes that an extra runner exists, not why it was launched.

## B. Retained MVP findings — not operational deviations

| Pair | Run ID | Failed check | Recorded answer/action | Frozen expected missing | Recorded missing |
|---|---|---|---|---|---|
| S2-R01 | `mvp-s2-r01-20260808T024118417834Z-426ab1cb` | `S2-T03-MISSING-INFORMATION` | `sufficient → move_next` | none | `contextual triggers` |
| S7-R01 | `mvp-s7-r01-20260808T050353042877Z-96b8f902` | `S7-T02-MISSING-INFORMATION` | `sufficient → move_next` | none | `contextual triggers` |
| S8-R01 | `mvp-s8-r01-20260808T052009293735Z-3167b0e2` | `S8-T02-MISSING-INFORMATION` | `sufficient → move_next` | none | `contextual triggers` |

All three failures are coded to AC and MIV. They remain ineligible formal results and must not be repaired in place.

## C. Retained baseline execution findings — not operational deviations

All entries below are `BaselineExecutionError` observations caused by divergence between the model-managed section reached and the next frozen target. They are retained as results.

| Pair | Last saved step | Stop reason |
|---|---|---|
| S1-R01 | S1-T02 | S1-T03 reached `triggers_signs`, not frozen target `coping_support` |
| S1-R03 | S1-T04 | S1-T05 reached `support_concept_reaction`, not frozen target `public_use_acceptability` |
| S2-R01 | S2-T05 | S2-T06 reached `support_concept_reaction`, not frozen target `public_use_acceptability` |
| S2-R02 | S2-T05 | S2-T06 reached `support_concept_reaction`, not frozen target `public_use_acceptability` |
| S2-R03 | S2-T05 | S2-T06 reached `support_concept_reaction`, not frozen target `public_use_acceptability` |
| S3-R01 | S3-T05 | S3-T06 reached `support_concept_reaction`, not frozen target `public_use_acceptability` |
| S3-R02 | S3-T03 | S3-T04 reached `triggers_signs`, not frozen target `coping_support` |
| S3-R03 | S3-T05 | S3-T06 reached `support_concept_reaction`, not frozen target `public_use_acceptability` |
| S4-R01 | S4-T02 | S4-T03 reached `triggers_signs`, not frozen target `coping_support` |
| S5-R01 | S5-T01 | S5-K01 reached `experience`, not frozen target `triggers_signs` |
| S6-R01 | S6-T02 | S6-T03 reached `experience`, not frozen target `triggers_signs` |
| S6-R02 | S6-T03 | S6-T04 reached `triggers_signs`, not frozen target `coping_support` |
| S6-R03 | S6-T02 | S6-T03 reached `experience`, not frozen target `triggers_signs` |
| S7-R01 | S7-T01 | S7-T02 reached `experience`, not frozen target `triggers_signs` |
| S8-R01 | S8-T01 | S8-T02 reached `experience`, not frozen target `triggers_signs` |

S1-R02 is the only completed and eligible prompt-only baseline attempt.

## D. No additional detected operational deviation

Read-only verification found one unique value across all 32 counted attempts for commit, tree, clean-worktree status, freeze hash, scenario hash, metric-rules hash, review-policy hash, model, transport, formal reviewer, and run type. All 603 archived source files matched the frozen physical-file manifest.

This means no additional deviation was detected in the archived evidence. It is not a claim about events that were never recorded.

