# PurrStone v9 Formal-Evidence Audit — FINAL

Date: 2026-08-08 (Asia/Taipei)  
Stage covered: frozen machine-evaluation evidence  
Audit mode: read-only verification and derived analysis; no runner, validator, API call, oracle, prompt, scenario, or frozen source record was changed or rerun.

## 1. Audit conclusion

The frozen machine-evaluation stage is complete and internally consistent.

The supplied source archive, `PurrStone-v9-formal-evidence(5).zip`, passed ZIP integrity testing and has SHA-256:

`4B59120BF89ED27A8A1D0606AF3D216BDCBB4BAE3EC528383FE797EA2A516E4F`

Independent read-only recalculation verified:

- all 16 frozen matched pairs;
- all 32 counted formal attempts: 16 MVP and 16 prompt-only baseline;
- all 32 runner-to-validator links in `formal_attempt_manifest.csv`;
- all 32 recorded runner hashes and all 32 validator hashes;
- all 603 source-file paths, sizes, and SHA-256 values in `physical_source_files_sha256.csv`;
- all four payload hashes in `snapshot_payload_sha256.csv`;
- the one retained but excluded S1-R01 duplicate record and its hash;
- consistency between the manifest counts and `integrity_summary.json`.

No verification error remained after applying the package's documented condition-label mapping: manifest label `baseline` corresponds to stored condition `prompt_only_baseline`.

## 2. Frozen identity

All 32 counted attempts share the following recorded identity:

| Field | Frozen value |
|---|---|
| Git commit | `be2c30a8e5e08036ed29da89645e60c71f423cf1` |
| Git tree | `12d6d758043b27980b39a6a52c68bbfec3b56b75` |
| Tracked worktree | clean |
| Freeze manifest SHA-256 | `3fe59daa2afc497b62df781f05abc5004e055de6f86b693092a606c62a8950cb` |
| Scenario specification SHA-256 | `09be36384bfcb7e369b0dea43d165e24c4923c9fbfea3b00ff3d71a7907f86d6` |
| Metric-rules SHA-256 | `9c37bb10d9ae6dcf56f25717b682a33c4cfab1b7780a1fc611ab18070808b782` |
| Review-policy SHA-256 | `74b32fd74d45033331d32f3aae605e68066f1b86ef98e44d3c2c48f6ef064c72` |
| Model | `gpt-4.1-mini` |
| Transport | `openai_responses_api` |
| Formal reviewer | `jingyang_reviewer` |
| Run type | `formal` |

This supports the narrower statement that the 32 counted attempts were recorded under one frozen code/configuration identity. It does not by itself establish external validity or production reliability.

## 3. Pre-formal technical evidence

### 3.1 Clean checks

Primary log: `01_clean_tests/clean_checks_full_fixed_20260808_040737.txt`

Recorded results:

- specification validation: PASS;
- Django system check: no issues;
- migration-drift check: no changes detected;
- full test suite: 162 tests run, all passed;
- test exit code: 0;
- tracked worktree after checks: clean.

The earlier `clean_checks_full_20260808_035545.txt` is retained as an incomplete wrapper log. The fixed log records that the wrapper had stopped because normal native stderr was treated as a PowerShell error; it was not a test failure.

### 3.2 Live OpenAI end-to-end check

Primary log: `02_live_openai/live_e2e_auditable_20260807_215004.txt`

Recorded results:

- status: PASS;
- real OpenAI semantic assessment: exercised;
- real constrained follow-up wording: exercised;
- public participant route: exercised;
- authenticated and attributable researcher review: exercised;
- transcript-linked topic evidence: exercised;
- Evidence Record rendering with reviewer identity: exercised;
- QA database transaction: rolled back;
- process exit code: 0;
- tracked worktree after the check: clean.

This supports functional end-to-end feasibility for the tested vertical slice. It does not establish researcher adoption, interview quality, scalability, or production readiness.

## 4. Frozen formal results

| Measure | MVP | Prompt-only baseline | Total counted |
|---|---:|---:|---:|
| Formal attempts | 16 | 16 | 32 |
| Runner completed | 16 | 1 | 17 |
| Runner execution error | 0 | 15 | 15 |
| Formally eligible | 13 | 1 | 14 |
| Formally ineligible | 3 | 15 | 18 |

Physical records additionally contain one completed, unvalidated S1-R01 MVP duplicate. It is retained for provenance but excluded from the 32-attempt denominator.

### 4.1 Three MVP ineligibility findings

The three ineligible MVP attempts are:

| Pair | Failed check | Metric codes | Recorded decision | Finding |
|---|---|---|---|---|
| S2-R01 | `S2-T03-MISSING-INFORMATION` | AC, MIV | `sufficient → move_next` | expected no missing item; recorded `contextual triggers` |
| S7-R01 | `S7-T02-MISSING-INFORMATION` | AC, MIV | `sufficient → move_next` | expected no missing item; recorded `contextual triggers` |
| S8-R01 | `S8-T02-MISSING-INFORMATION` | AC, MIV | `sufficient → move_next` | expected no missing item; recorded `contextual triggers` |

In each case, the high-level routing action was correct, while the evidence-status annotation was inconsistent with the frozen oracle. These are retained formal findings, not reasons to edit or rerun the evidence.

### 4.2 Fifteen prompt-only baseline execution errors

Fifteen baseline attempts stopped when the model-managed section trajectory diverged from the next frozen target in the pre-registered participant sequence. The harness stopped rather than supplying an answer intended for a different section. Only S1-R02 completed and was formally eligible.

The defensible interpretation is therefore limited:

- the prompt-only condition showed low compatibility with this fixed frozen trajectory under this harness (`1/16` completed and eligible);
- the stopped runs preserve their pre-stop requests, responses, state, error, and validator output;
- downstream Evidence Record quality is not evaluated for the 15 stopped attempts;
- these results do not establish that the prompt-only baseline is generally inferior in interview quality, summary quality, or real-world usefulness.

## 5. S2 repeatability finding

A separate read-only comparison linked S2-R01, S2-R02, and S2-R03 target step T03 to raw-model-call array index 3 / `call_index=4`, kind `semantic_assessment`.

Across the three repetitions:

- the embedded requests were structurally identical;
- the recorded settings were identical: `gpt-4.1-mini`, temperature 0, and 500 maximum output tokens;
- PowerShell compact-serialization request SHA-256: `FD7666890331669A05BD6FC953EE51ABB3079FF144894C4AF18248F354FD0890` for all three;
- independent Python compact-JSON request SHA-256: `FE276944CA26A228C3884A425E82CE4BFC21E1E871FE1C40DCDD42BEE26F70CA` for all three;
- output-text SHA-256 values were all different;
- S2-R01 retained the incorrect missing-information annotation; S2-R02 and S2-R03 passed;
- all three still recorded `sufficient → move_next`.

This dataset therefore shows run-to-run variation in the LLM-based semantic annotation for an identical recorded request. It does not show a deterministic workflow-code failure, and it does not justify changing the frozen S2-R01 result.

Full values are preserved in `S2_exact_request_comparison_2026-08-08.txt`.

## 6. What the automated evidence does and does not establish

The machine evaluation is an artificial, controlled evaluation of a designed artefact and its recorded state transitions. It provides evidence about the tested workflow properties under the frozen scenarios. Design-science evaluation literature requires the evaluation goals, strategy, properties, and episodes to be stated explicitly rather than treating one evaluation type as proof of every intended outcome ([Venable, Pries-Heje, & Baskerville, 2016](https://doi.org/10.1057/ejis.2014.36)).

Supported within the tested vertical slice:

- executable end-to-end workflow feasibility;
- frozen-protocol action and state checks;
- bounded participant controls represented by the scenario suite;
- persistence of transcript, decision, structured-evidence, source-link, review, and rendering artefacts where the run reached those stages;
- attributable researcher review events;
- observed differences from the frozen prompt-only condition;
- explicit retention of failures and limitations.

Not established by this evidence alone:

- generally better interviews or insights;
- meaning preservation or absence of unsupported content;
- researcher usefulness, acceptance, or adoption;
- participant experience in natural use;
- time saving or organisational scalability;
- cross-protocol or cross-domain reliability;
- superiority to commercial platforms;
- production readiness.

All 32 validator results explicitly leave MP (meaning preservation) and UCR (unsupported-content/atomic-proposition coding) pending. Human evaluation should state exactly who judged what material, under which criteria and procedure; unclear constructs and reporting weaken reproducibility ([Howcroft et al., 2020](https://aclanthology.org/2020.inlg-1.23/)).

## 7. Evidence still required for the resit argument

The formal machine-evaluation package is complete, but the overall project evaluation is not complete. Remaining work is:

1. Freeze and complete human MP/UCR coding for evaluable outputs, with explicit N/A handling for stopped runs.
2. Conduct ethically authorised target-researcher evaluation of reviewability/usefulness, retaining the guide, materials shown, raw responses, coding, and quotations.
3. Complete the public-evidence SOTA/competitor capability matrix and derive success criteria from cited evidence.
4. Complete the need → requirement → mechanism → observable success criterion → metric → result → claim-boundary traceability matrix.
5. Produce the remaining S2–S8 thesis figures and a screenshot manifest linked to source run IDs; current `08_thesis_figures` coverage is S1 only.
6. Preserve at least one actual PDF export if the report claims PDF export was tested; the current package contains Evidence Record HTML renders but no PDF file.
7. Write the report using the bounded claim above and explicitly report the baseline completion limitation.

For qualitative follow-up, a semi-structured guide should be developed systematically rather than improvised ([Kallio et al., 2016](https://doi.org/10.1111/jan.13031)), and analysis should retain a transparent audit trail to support trustworthiness ([Nowell et al., 2017](https://doi.org/10.1177/1609406917733847)).

## 8. Final claim boundary for this stage

A defensible stage-level claim is:

> In a frozen PurrStone/Sensory Overload vertical slice, the implemented system connected participant responses, bounded interview actions, transcript-grounded draft evidence, visible limitations, and attributable researcher review in an inspectable and traceable interview-to-review workflow. Controlled formal runs demonstrated end-to-end execution for all 16 MVP attempts, with 13/16 meeting every frozen automatic check; three retained failures concerned missing-information annotation while preserving the correct routing action. The prompt-only comparison was limited by frozen-sequence divergence in 15/16 attempts, so it supports a narrow workflow-compatibility comparison rather than a general claim of superior interview or outcome quality.

Do not rerun, overwrite, or repair the frozen 32 attempts. Any classification correction must be separately labelled `post-evaluation correction` and must not replace the archived formal evidence.

