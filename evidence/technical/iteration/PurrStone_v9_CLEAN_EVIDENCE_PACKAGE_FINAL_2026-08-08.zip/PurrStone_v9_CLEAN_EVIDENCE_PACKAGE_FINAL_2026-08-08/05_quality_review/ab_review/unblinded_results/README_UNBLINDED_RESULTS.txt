PurrStone A/B unblinded results package
======================================

Status: PASS
Generated (UTC): 2026-08-08T12:46:37.798Z

The blind consensus workbook was frozen and hashed before the condition key was opened.
The reviewer-returned original is preserved in ../blind_freeze; an administrator-validated copy restores only the frozen Agreement and QA formulas.

Headline descriptive results
- MVP completed: 16/16; prompt-only baseline completed: 1/16.
- Failure-inclusive preference: MVP 15/16; prompt-only baseline 0/16; Tie 1/16.
- Independent exact agreement: 74.86% across 183 comparable judgement cells.
- Q3/Q5 baseline available-case n=1; do not use those means for a general output-quality claim.

Use PurrStone_AB_UNBLINDED_RESULTS_2026-08-08.xlsx for the human-readable analysis and the CSV files for machine-readable audit.
See the JSON manifest for hashes, computed summaries and claim boundaries.
