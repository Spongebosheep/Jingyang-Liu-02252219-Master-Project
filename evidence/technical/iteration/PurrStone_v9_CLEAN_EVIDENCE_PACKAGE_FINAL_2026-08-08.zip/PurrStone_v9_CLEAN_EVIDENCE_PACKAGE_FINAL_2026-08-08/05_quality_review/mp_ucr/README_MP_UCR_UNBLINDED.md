# PurrStone MP/UCR unblinded analysis

Status: PASS after blind workbook freeze and private-key verification.

## Primary definitions

- Meaning preservation (MP) is coded once per source-linked generated draft.
- Unsupported claim rate (UCR) = Unsupported / (Supported + Unsupported).
- `Unclear` claims are excluded from the UCR denominator and reported separately.
- Predefined N/A items and attempts without a completed downstream draft are not scored as failures.

The denominator definition was fixed for the final analysis after the blind coder workbook had been frozen. It did not change the numerical result because the coder assigned zero `Unclear` claims.

## Results boundary

This is a one-coder, descriptive analysis of source faithfulness in a frozen scripted corpus. It does not establish inter-rater reliability, interview quality, real-world factual truth, natural-use performance, scalability, researcher acceptance, general comparative superiority, or superiority over commercial products. The prompt-only baseline generated a completed output for only one of sixteen attempts, so its MP/UCR result applies only to that observed output.

## Method sources

- https://aclanthology.org/W19-8643/
- https://aclanthology.org/2020.inlg-1.23/
- https://aclanthology.org/2020.acl-main.173/
- https://aclanthology.org/2023.emnlp-main.741/

These sources inform evaluation design and operationalisation; they do not validate this corpus or its results.
