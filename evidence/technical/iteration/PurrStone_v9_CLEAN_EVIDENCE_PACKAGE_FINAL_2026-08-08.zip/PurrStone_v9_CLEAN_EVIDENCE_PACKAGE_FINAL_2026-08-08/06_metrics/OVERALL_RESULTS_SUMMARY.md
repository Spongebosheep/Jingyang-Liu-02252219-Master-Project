# PurrStone v9 Overall Results Summary

Date: 2026-08-08 (Asia/Taipei)  
Analysis type: frozen, scripted, descriptive, formative evaluation

## 1. Technical readiness for the formal evaluation

The recorded frozen build passed specification validation, the Django system check, the migration-drift check, and all 162 tests. One live OpenAI end-to-end vertical-slice check also passed. These findings establish technical feasibility for the tested path, not production readiness, organisational scalability, or natural-use reliability.

## 2. Formal machine evaluation

| Measure | MVP | Prompt-only baseline | Total |
|---|---:|---:|---:|
| Counted attempts | 16 | 16 | 32 |
| Runner completed | 16 | 1 | 17 |
| Execution error | 0 | 15 | 15 |
| Formally eligible | 13 | 1 | 14 |
| Formally ineligible | 3 | 15 | 18 |

The three ineligible MVP attempts—S2-R01, S7-R01, and S8-R01—retained the expected high-level routing action but incorrectly recorded `contextual triggers` as missing. The 15 baseline attempts stopped when the model-managed section trajectory diverged from the next fixed participant target; the harness stopped rather than supplying an answer intended for another section.

The defensible comparison is therefore workflow compatibility with the fixed frozen trajectory. It is not a general comparison of interview quality, insight quality, or real-world usefulness.

## 3. Blinded A/B review

Two independent reviewers produced 183 applicable judgement cells, with 137 exact agreements (74.8634%) and 46 disagreements. All 46 disagreements were resolved in the frozen consensus workbook before unblinding. Structural N/A cells were excluded rather than scored as zero.

The adjudicated failure-inclusive preferences were:

- MVP: 15/16 pairs;
- prompt-only baseline: 0/16;
- tie: 1/16.

This preference count includes execution failure consequences. It cannot isolate a single causal mechanism, and the baseline's downstream Q3/Q5 available-case sample is only one. No inferential significance test is reported.

## 4. MP and UCR human coding

The condition-masked coding target was the generated structured-evidence draft before researcher review.

- 85 topic items were represented;
- 80 items were evaluable and source-linked;
- five unavailable topic records were predefined N/A;
- one coder marked 80/80 evaluable drafts `Preserved`;
- 396 atomic propositions were coded `Supported`;
- zero were `Unsupported`;
- zero were `Unclear`.

The project definition used for the final analysis is:

`UCR = Unsupported / (Supported + Unsupported)`

Accordingly, UCR is `0 / (396 + 0) = 0%`. Unclear is excluded from the denominator and reported separately as zero. The result is limited to one coder and the completed scripted corpus. It does not justify a universal zero-hallucination claim.

Among complete matched outputs, only five topic-level pairs were available, all from S1-R02; both conditions tied on MP and UCR in those five completed-output comparisons.

## 5. Implementation evidence status

The R1–R5 implementation table contains exactly 28 subchecks:

| Status | Count | Interpretation |
|---|---:|---|
| PASS | 24 | Direct frozen evidence in the stated scripted scope |
| PARTIAL | 3 | Evidence exists but a failure or missing path prevents a full pass |
| NOT TESTED | 1 | No direct archived test identified |

The PARTIAL rows are:

- R1.5: missing-information annotation matched the frozen oracle in 13/16 MVP runs, with three retained failures;
- R3.4: a boundary-message exclusion negative test exists, but separately injected wrong-session and wrong-topic rejection attempts were not identified;
- R5.6: the non-approval/revision path was tested, but no successful final-approval run was archived.

The NOT TESTED row is R5.7: post-approval content mutation reopening approval.

## 6. Runtime and protocol identity

Canonical JSON hashing of the embedded runtime identities produced two expected condition-specific variants:

- MVP runner identity SHA-256: `b63eba3f4437e749fc774a5dace491a56f15c75dbb5838a9a933c9cbc4c417d6`;
- prompt-only baseline runner identity SHA-256: `713e26a70669c45c01c22b4c3cb7897aafd380cf71b454cf9b1f66524eec5468`.

All 32 counted attempts share one canonical protocol snapshot SHA-256:

`67f9f8f222c631f235c7e25b9633efb2bdb6646b9e9eb8d6644499464f51bee6`

The canonical hash matched the recorded protocol hash in every counted runner record. Runtime identity establishes provenance, not deterministic model output; archived S2 repetitions produced different output hashes from identical recorded semantic-assessment requests.

## 7. Final bounded claim

> In a frozen PurrStone/Sensory Overload vertical slice, the implemented system connected participant responses, bounded interview actions, transcript-grounded draft evidence, visible limitations, and attributable scripted researcher review in an inspectable workflow. All 16 MVP attempts completed, with 13/16 meeting every frozen automatic check; three retained failures concerned missing-information annotation while preserving the correct routing action. The prompt-only comparison was limited by frozen-sequence divergence in 15/16 attempts, so it supports a narrow workflow-compatibility comparison rather than a general claim of superior interview or outcome quality. Within completed outputs, the single condition-masked coder marked all 80 evaluable drafts Preserved and all 396 atomic claims Supported (UCR 0%).

## 8. Reporting facts still requiring user confirmation

- coder relationship and recruitment route;
- coder compensation;
- ethics/consent basis for the human coding activity;
- coder's prior exposure to the A/B materials.

These facts cannot be inferred from the workbooks and remain explicitly pending.
