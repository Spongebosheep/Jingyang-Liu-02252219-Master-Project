# PurrStone v9 Clean Evidence Package — Tutor / Examiner Review Copy

Date: 2026-08-08 (Asia/Taipei)  
Mode: read-only consolidation of frozen evidence and derived analysis  
Status: package integrity verified; unresolved reporting facts and evidence gaps are listed explicitly

## Read this first

This package contains the frozen machine-evaluation records, clean-test and live-E2E logs, condition-separated scenario evidence, condition-masked A/B review, condition-masked MP/UCR coding, final metrics, the 28-row implementation-status table, the claim-to-evidence map, runtime/protocol hashes, and source-verified screenshots.

The 32 counted attempts were not rerun, repaired, or overwritten. Derived summaries are labelled. Private unblinding-key ZIPs, administrator-only packages, blank coder kits, duplicate working files, API credentials, private tutoring materials, and the obsolete machine-stage index have been excluded.

## Headline results

- Clean technical checks: specification validation PASS; Django system check clean; no migration drift; 162/162 tests passed.
- Live OpenAI vertical slice: PASS for the archived auditable path.
- Formal machine evaluation: MVP 16/16 completed and 13/16 formally eligible; prompt-only baseline 1/16 completed and eligible.
- A/B review: two independent coders completed the blind review; 46 disagreements were resolved before unblinding. Consensus preference was MVP 15/16, tie 1/16, baseline 0/16.
- MP: one condition-masked coder marked 80/80 evaluable drafts Preserved; five unavailable topic records were predefined N/A.
- UCR: 0 Unsupported / (396 Supported + 0 Unsupported) = 0%; Unclear was excluded from the denominator and separately reported as 0.
- Implementation status: 24 PASS, 3 PARTIAL, 1 NOT TESTED across the 28-row R1–R5 table.
- Runtime provenance: two expected condition-specific runtime-identity hashes and one canonical protocol-snapshot hash across all 32 counted attempts.

## Defensible conclusion

In a frozen PurrStone/Sensory Overload vertical slice, the implemented system connected participant responses, bounded interview actions, transcript-grounded draft evidence, visible limitations, and attributable scripted researcher review in an inspectable workflow. All 16 MVP attempts completed, with 13/16 meeting every frozen automatic check; three retained failures concerned missing-information annotation while preserving the expected routing action.

The prompt-only comparison was limited by frozen-sequence divergence in 15/16 attempts. It therefore supports a narrow workflow-compatibility comparison, not a general claim of superior interview or outcome quality. Within completed outputs, the single MP/UCR coder marked all 80 evaluable drafts Preserved and all 396 atomic claims Supported. This one-coder result is descriptive and does not establish inter-rater reliability or universal fidelity.

## Claims not established by this package

- generally better interviews or insights;
- target-researcher usefulness, acceptance, or adoption;
- natural participant experience;
- cross-domain or cross-protocol reliability;
- scalability, production readiness, or commercial-platform superiority;
- universal meaning preservation or universal absence of unsupported content;
- tested Evidence Record PDF export;
- deterministic, bit-for-bit LLM output reproducibility.

## Open evidence actions

1. Preserve one actual Evidence Record PDF export.
2. Archive separately injected wrong-session and wrong-topic source-rejection tests.
3. Test a successful final-approval path.
4. Test post-approval mutation reopening approval.
5. Record coder relationship/recruitment, compensation, ethics/consent basis, and prior A/B exposure accurately.
6. Conduct an ethically authorised target-researcher evaluation.
7. Complete the public-evidence competitor/SOTA capability matrix.

Any new test must be stored as a separately versioned post-evaluation artefact. Do not alter the frozen 32 attempts.

## Package structure

- `00_version`: frozen and packaged manifests, runtime/protocol hashes, integrity records, and excluded-duplicate provenance.
- `01_clean_tests`: pre-formal technical logs.
- `02_live_openai`: live OpenAI end-to-end logs.
- `03_scenarios/mvp`: 16 counted MVP run directories.
- `04_scenarios/baseline`: 16 counted prompt-only baseline run directories.
- `05_quality_review`: machine audit, A/B review, and MP/UCR coding evidence.
- `06_metrics`: final report-ready metrics and consolidated summaries.
- `07_implementation_status`: 28-row status workbook/CSV/JSON and claim-to-evidence map.
- `08_thesis_figures`: 35 source-verified screenshots and their provenance manifest.

`MANIFEST_SHA256.csv` covers every packaged file except itself and the outer ZIP. `PACKAGE_VERIFICATION.json` records structural, hash, spreadsheet, and leakage checks. See `EVIDENCE_INDEX_FINAL.md` for the detailed map.

## Human-evaluation reporting facts still pending

The workbooks establish coder IDs, backgrounds, declarations, blind procedure, frozen outputs, and results. The following contextual facts are not present in the returned files and must not be invented:

- relationship between each coder and the project/student;
- recruitment route;
- compensation;
- ethics/consent basis;
- prior exposure to the A/B materials.

## Methodological reporting anchors

- Venable, Pries-Heje, and Baskerville (2016): https://doi.org/10.1057/ejis.2014.36
- van der Lee et al. (2019): https://aclanthology.org/W19-8643/
- Howcroft et al. (2020): https://aclanthology.org/2020.inlg-1.23/
- Artstein and Poesio (2008): https://aclanthology.org/J08-4004/
- Maynez et al. (2020): https://aclanthology.org/2020.acl-main.173/
- Min et al. (2023), atomic-proposition decomposition logic adapted here: https://aclanthology.org/2023.emnlp-main.741/

These sources justify evaluation design and reporting choices; they do not themselves validate the system or its results.
