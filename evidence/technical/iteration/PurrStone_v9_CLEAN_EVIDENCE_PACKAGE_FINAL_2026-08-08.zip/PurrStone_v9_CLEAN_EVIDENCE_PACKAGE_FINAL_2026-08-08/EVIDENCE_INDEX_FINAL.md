# PurrStone v9 Final Evidence Index

## Root controls

| File | Purpose |
|---|---|
| `README_FIRST.md` | Headline results, claim boundaries, open actions, and package navigation |
| `WHAT_TO_SEND_TUTOR.md` | Exact sharing instructions for the private tutor |
| `MANIFEST_SHA256.csv` | SHA-256 and byte size for every packaged file except itself and the outer ZIP |
| `PACKAGE_VERIFICATION.json` | Structural, hash, spreadsheet, count, and leakage verification |

## `00_version`

| Evidence | Purpose |
|---|---|
| `formal_attempt_manifest_original.csv` | Original frozen 32-attempt manifest |
| `formal_attempt_manifest_packaged.csv` | Paths normalised to the condition-separated package |
| `integrity_summary.json` | Frozen denominator, completion/error, eligibility, and physical-file counts |
| `physical_source_files_sha256.csv` | Frozen physical source-file inventory |
| `snapshot_payload_sha256.csv` | Frozen payload hashes |
| `excluded_record_manifest.csv` | One retained, unvalidated S1-R01 MVP duplicate excluded from denominators |
| `excluded_duplicate_record/` | Byte-preserved excluded duplicate runner directory |
| `runtime_identity_manifest.csv` | Per-attempt canonical runtime and protocol hashes |
| `runtime_identity_summary.json` | Two runtime variants, one protocol variant, canonicalisation rule, and boundary |

Private tutoring materials have been removed from this directory.

## `01_clean_tests`

Primary source: `clean_checks_full_fixed_20260808_040737.txt`.

Recorded: specification validation PASS; Django check clean; no migration drift; 162 tests passed; worktree clean. Earlier wrapper logs remain as operational provenance and are not treated as failed tests.

## `02_live_openai`

Primary source: `live_e2e_auditable_20260807_215004.txt`.

Recorded: one real OpenAI semantic-assessment and constrained-follow-up path, public participant route, authenticated researcher review, transcript-linked evidence, Evidence Record HTML rendering, rolled-back QA transaction, and clean worktree.

## `03_scenarios/mvp`

Exactly 16 counted MVP directories. Each retains its runner record, raw model calls, raw HTTP artefacts, archived pages, validator result, and any review events.

## `04_scenarios/baseline`

Exactly 16 prompt-only baseline directories: one completed and 15 retained execution errors. Stopped records preserve pre-stop requests, responses, state, error, and validator output.

## `05_quality_review/machine_audit`

| File | Purpose |
|---|---|
| `PurrStone_v9_formal_evidence_audit_FINAL_2026-08-08.md` | Independent read-only machine-evidence audit |
| `formal_deviation_log_FINAL.md` | Operational deviation, three MVP findings, and 15 baseline findings |
| `read_only_verification_summary.json` | Verified counts and frozen identity |
| `S2_exact_request_comparison_2026-08-08.txt` | Identical-request/different-output repeatability evidence |

The obsolete machine-stage evidence index was removed because it incorrectly described later-completed MP/UCR and screenshot work as pending.

## `05_quality_review/ab_review`

Contains the original returned consensus workbook, administrator-validated frozen copy, freeze manifest, unblinded results workbook, analysis manifest, and result CSVs. The two coders completed 183 comparable judgement cells; 46 disagreements were resolved before unblinding. Private condition keys and administrator-only ZIPs are excluded.

## `05_quality_review/mp_ucr`

Contains the returned coder workbook, administrator-verified freeze, blind QA, unblinded results, result CSV/JSON files, and freeze/unblinding manifest. Five unavailable topics remain predefined N/A. UCR is Unsupported divided by Supported plus Unsupported; Unclear is separate. The denominator-definition screenshot was removed as a private tutoring artefact; the definition remains documented in the README and result files.

## `06_metrics`

| Evidence | Purpose |
|---|---|
| `PurrStone_v9_FORMAL_METRICS_REPORT_READY_FINAL_2026-08-08.xlsx` | Final machine metrics plus completed MP/UCR and A/B status/denominators |
| `formal_result_summary.csv` | Formal machine denominator and completion/eligibility breakdown |
| `ab_unblinded_analysis_manifest.json` | A/B design, agreement, completion, preference, flags, and boundaries |
| `mp_ucr_unblinded_results.json` | MP/UCR counts, denominators, limitations, and definition timing |
| `OVERALL_RESULTS_SUMMARY.md` | Consolidated machine, A/B, MP/UCR, implementation, and runtime results |

## `07_implementation_status`

Primary workbook: `PurrStone_v9_IMPLEMENTATION_STATUS_AND_CLAIM_MAP_v1_2026-08-08.xlsx`.

It contains five sheets: README, exactly 28 R1–R5 rows, an 18-row claim-to-evidence map, the 32-row runtime identity manifest, and seven open actions. CSV and JSON copies support independent recalculation.

## `08_thesis_figures`

Thirty-five PNG screenshots cover all 32 counted attempts: 17 output-review screenshots and 18 validator-failure screenshots. Source hashes were checked against the frozen physical-file inventory. Screenshots support interface-presentation and archived-state claims; runner JSON and validator records remain the primary state evidence.

## Deliberate exclusions

- private unblinding keys and randomisation seeds;
- administrator-only evidence packages and tools;
- blank coder kits/templates;
- private tutoring documents and screenshots;
- duplicate and intermediate workbooks;
- API keys, identifiable databases, and unrelated project files.
