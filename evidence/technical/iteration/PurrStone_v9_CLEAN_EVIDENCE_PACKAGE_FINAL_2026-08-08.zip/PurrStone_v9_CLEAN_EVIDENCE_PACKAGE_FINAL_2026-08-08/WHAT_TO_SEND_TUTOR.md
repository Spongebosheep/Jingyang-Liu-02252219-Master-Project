# What to send to the private tutor

## Send these two ZIP files

1. `PurrStone_v9_TUTOR_CORE_REVIEW_FILES_FINAL_2026-08-08.zip`  
   Start here. It contains the final results workbooks, implementation-status/claim map, overall summary, runtime/protocol identity, and the disclosure of remaining reporting facts.

2. `PurrStone_v9_CLEAN_EVIDENCE_PACKAGE_FINAL_2026-08-08.zip`  
   Full audit package. Send this as the supporting archive so the tutor can inspect the 32 frozen attempts, validator evidence, screenshots, blinded-review provenance, and hashes.

## Ask the tutor to review

- whether the bounded claim matches the evidence;
- how to report the 15/16 baseline completion failures without treating missing outputs as zero quality;
- whether the A/B and one-coder MP/UCR limitations are stated clearly enough;
- whether the three PARTIAL and one NOT TESTED implementation rows require new evidence before submission;
- whether the remaining coder relationship/recruitment, compensation, ethics/consent, and prior-exposure facts need to appear in the report or appendix;
- whether an actual Evidence Record PDF and the missing approval/negative-test paths are essential before submission.

## Do not send

- `PurrStone_AB_ADMIN_EVIDENCE_PACKAGE_v1_2026-08-08.zip`;
- `PurrStone_MP_UCR_ADMIN_EVIDENCE_PACKAGE_v1_2026-08-08.zip`;
- either private unblinding-key ZIP;
- blank coder kits, templates, scripts, private tutoring records, or the original 1,033-entry working archive;
- API credentials, identifiable databases, or unrelated source documents.

Administrator packages and the original working archive should be retained privately only for provenance and recovery.
