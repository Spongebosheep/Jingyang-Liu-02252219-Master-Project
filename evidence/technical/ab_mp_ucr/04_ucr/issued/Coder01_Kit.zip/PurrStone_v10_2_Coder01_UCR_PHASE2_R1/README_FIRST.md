# Coder01 UCR Phase 2 package

1. Read `CODING_PROTOCOL_PHASE2.md`.
2. Open `ITEM_INDEX_PHASE2.html` to inspect each blind item's final reviewed evidence and participant source.
3. Complete every yellow input cell in `Coder01_PurrStone_v10_2_UCR_Phase2_Coding_Workbook.xlsx`.
4. Confirm `QA Summary` and `Start Here` show PASS.
5. Return only the completed workbook.

The proposition inventory is frozen at 46 nominal propositions across nine blind items. Its SHA-256 is `f8708132168cb35d63769dc2c50929bc67ab6856e991a9accb53ad0efe3645d6`. No support label is prefilled.
