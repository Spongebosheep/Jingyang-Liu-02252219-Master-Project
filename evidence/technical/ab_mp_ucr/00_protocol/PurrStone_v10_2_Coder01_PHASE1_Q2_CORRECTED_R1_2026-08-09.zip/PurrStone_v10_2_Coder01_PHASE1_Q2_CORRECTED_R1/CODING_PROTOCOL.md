# Independent blinded coding protocol

## Independence and blinding

Complete this workbook independently. Do not seek the A/B assignment key,
inspect filenames outside this kit, discuss judgements with another coder, or
change locked metadata. The researcher must retain both original submissions
before any consensus discussion or unblinding.

## Part A — A/B output quality (formal primary analysis)

For each of the 10 complete matched pairs, review opaque materials A and B and
score each criterion from 1 (very poor) to 5 (very strong):

1. **Q1 Protocol coverage** — How well the material addresses information required by the Protocol.
2. **Q2 Probing relevance and neutrality** — Whether a missing-information probe targets the identified gap, is concise, and is not leading. Use `N/A` when neither A nor B contains a missing-information probe; the workbook pre-fills all six eligible N/A pairs. Skip handling, Stop handling, boundary responses, and ordinary primary-topic questions are not probes for Q2.
3. **Q3 Transcript grounding and fidelity** — Whether draft evidence is supported by participant sources and preserves participant meaning.
4. **Q4 Participant clarity and control** — Whether questions, Skip, Stop, boundary, and missing-information handling are clear.
5. **Q5 Researcher reviewability** — Whether a researcher can inspect and decide Include, Edit, or Exclude.

Then record overall preference (`A`, `B`, or `Tie`), confidence (1–3), a short
rationale, a valid JSON issue list such as `[]`, and an ISO-8601 timestamp with
timezone.

## Part B — Meaning Preservation (supplementary contract-clarification analysis)

For each of the nine blind items, compare `final reviewed evidence` with the
displayed participant source and label it:

- `preserved`: all material meaning is supported and no important source meaning is contradicted;
- `not_preserved`: at least one substantive meaning is added, removed, or contradicted;
- `uncertain`: evidence is genuinely insufficient for a confident binary judgement.

Add a concise source-based rationale and confidence (1–3). `uncertain` must not
be used merely to avoid a difficult decision.

## Part C — UCR proposition segmentation, Phase 1 (supplementary contract-clarification analysis)

Split each final reviewed evidence text into the smallest independently
supportable factual propositions. Record at least one proposition for every
item. Do **not** label support in Phase 1. Do not code interface labels or purely
stylistic framing as propositions. Number propositions from 1 with no gaps.

After both independent segmentations are locked, the administrator will
coordinate a common proposition inventory while condition and item identity
remain blind. That frozen inventory will be placed into two new Phase 2
workbooks. Each coder will then independently label every common proposition
`supported` or `unsupported`, add source-based rationale and confidence, and
return it before consensus. This separation makes initial label disagreement
measurable.

## Submission rule

Return the completed Phase 1 `.xlsx` only. Keep the filename and coder identity. A QA
cell that shows `PASS` is a convenience check, not proof; the administrator will
run a formula-independent validator. Do not perform consensus or unblinding.
