# Coder01 independent Phase 1 package

Open `CODING_PROTOCOL.md` and `PROTOCOL_REFERENCE.html`, then use `PAIR_INDEX.html` and `ITEM_INDEX.html`. Record A/B scores, MP labels and UCR segmentation in `Coder01_PurrStone_v10_2_Phase1_Coding_Workbook.xlsx`. Do not discuss, label UCR support, or unblind before submission.

> **Replacement build:** This Q2-applicability-corrected package supersedes any earlier Phase 1 ZIP for this coder. Use only this package. The blinded evidence materials are unchanged.
