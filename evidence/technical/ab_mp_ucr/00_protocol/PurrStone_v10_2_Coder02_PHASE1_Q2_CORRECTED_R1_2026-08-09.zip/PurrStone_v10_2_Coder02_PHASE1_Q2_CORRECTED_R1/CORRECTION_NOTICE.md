# Q2 applicability correction — replacement build

This package is build `purrstone-v10.2-pre-coder-q2-r1-20260809` and supersedes the earlier Phase 1 package
for `Coder02`. Q2 is scored only when at least one material contains a
missing-information follow-up probe. The workbook therefore pre-fills pair-level
`N/A` for pairs containing no such probe, including ordinary primary questions,
Skip/Stop handling and boundary responses.

The blinded A/B evidence materials, A/B assignments, MP/UCR materials and all
participant-source text are unchanged. Do not copy entries from, edit, or return
an earlier workbook.
